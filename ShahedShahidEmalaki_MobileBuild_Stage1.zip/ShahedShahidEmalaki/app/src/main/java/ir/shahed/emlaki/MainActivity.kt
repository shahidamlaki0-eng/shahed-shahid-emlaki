package ir.shahed.emlaki

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import android.content.Context

private val Navy = Color(0xFF14243A)
private val Gold = Color(0xFFC7A45A)
private val Paper = Color(0xFFF6F7FA)
private val Context.dataStore by preferencesDataStore(name = "student_profile")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Gold, background = Paper)) {
            ShahedApp(this)
        } }
    }
}

@Composable
private fun ShahedApp(context: Context) {
    val scope = rememberCoroutineScope()
    var grade by remember { mutableStateOf("") }
    var field by remember { mutableStateOf("") }
    var loaded by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("خانه") }

    LaunchedEffect(Unit) {
        val p = context.dataStore.data.first()
        grade = p[stringPreferencesKey("grade")].orEmpty()
        field = p[stringPreferencesKey("field")].orEmpty()
        loaded = true
    }

    if (!loaded) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return }

    if (grade.isBlank() || field.isBlank()) {
        SelectionScreen(
            onSave = { g, f ->
                scope.launch {
                    context.dataStore.edit {
                        it[stringPreferencesKey("grade")] = g
                        it[stringPreferencesKey("field")] = f
                    }
                    grade = g; field = f
                }
            }
        )
    } else {
        Scaffold(
            containerColor = Paper,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("خانه", "امتحانات", "هفتگی", "اطلاعیه‌ها", "تکالیف").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Icon(
                                when(item) {
                                    "امتحانات" -> Icons.Default.Event
                                    "هفتگی" -> Icons.Default.CalendarMonth
                                    "اطلاعیه‌ها" -> Icons.Default.Campaign
                                    "تکالیف" -> Icons.Default.MenuBook
                                    else -> Icons.Default.Home
                                }, contentDescription = item
                            ) },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Column(Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(24.dp)).padding(22.dp)) {
                        Text("شاهد شهید املاکی", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("پایه $grade • $field", color = Gold, fontSize = 14.sp)
                        Spacer(Modifier.height(16.dp))
                        Text("به مدرسه خوش آمدی", color = Color.White, fontSize = 16.sp)
                    }
                }
                item {
                    Text(page, color = Navy, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        when(page) {
                            "امتحانات" -> "هنوز برنامه امتحانی منتشر نشده است."
                            "هفتگی" -> "برنامه هفتگی کلاس هنوز ثبت نشده است."
                            "اطلاعیه‌ها" -> "در حال حاضر اطلاعیه‌ای منتشر نشده است."
                            "تکالیف" -> "تکلیفی برای این کلاس ثبت نشده است."
                            else -> "از این بخش می‌توانی برنامه امتحانات، کلاس‌ها و اطلاعیه‌های مدرسه را ببینی."
                        },
                        color = Color(0xFF667085), fontSize = 14.sp
                    )
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("اطلاعات مدرسه", color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("مدرسه شاهد شهید املاکی", color = Color.DarkGray, modifier = Modifier.padding(top = 8.dp))
                            Text("مدیریت: مدیریت مدرسه", color = Color.Gray, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
                item {
                    TextButton(onClick = {
                        scope.launch {
                            context.dataStore.edit { it.remove(stringPreferencesKey("grade")); it.remove(stringPreferencesKey("field")) }
                            grade = ""; field = ""
                        }
                    }) { Text("تغییر پایه و رشته") }
                }
            }
        }
    }
}

@Composable
private fun SelectionScreen(onSave: (String, String) -> Unit) {
    var grade by remember { mutableStateOf("دهم") }
    var field by remember { mutableStateOf("علوم تجربی") }
    val fields = listOf("علوم تجربی", "ریاضی فیزیک", "علوم انسانی")
    Column(
        Modifier.fillMaxSize().background(Paper).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("شاهد شهید املاکی", color = Navy, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("برای شروع، پایه و رشته‌ات را انتخاب کن.", color = Color.Gray, modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))
        Text("پایه تحصیلی", color = Navy, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 12.dp)) {
            listOf("دهم", "یازدهم", "دوازدهم").forEach {
                FilterChip(selected = grade == it, onClick = { grade = it }, label = { Text(it) })
            }
        }
        Text("رشته", color = Navy, fontWeight = FontWeight.Bold)
        fields.forEach {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = field == it, onClick = { field = it })
                Text(it, color = Navy)
            }
        }
        Spacer(Modifier.height(22.dp))
        Button(onClick = { onSave(grade, field) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Navy)) {
            Text("ذخیره و ورود", color = Color.White, modifier = Modifier.padding(6.dp))
        }
    }
}
